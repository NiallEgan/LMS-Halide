import org.scalatest.FlatSpec
import scala.collection.mutable.ListBuffer
import java.io.File

import sepia._

/*class DomainInferenceTest extends FlatSpec {
  "the identity program" should "have domain of ((0, w), (0, h))" {

  }
}*/
