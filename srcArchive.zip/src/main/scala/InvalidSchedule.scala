package sepia

class InvalidSchedule(message: String) extends Exception(message)