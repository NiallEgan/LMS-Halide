package sepia

class InvalidAlgorithm(message: String) extends Exception(message)
