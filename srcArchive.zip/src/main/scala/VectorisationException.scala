package sepia

class VectorisationException(message: String) extends Exception(message)
